# -*- coding: utf-8 -*-
from .version import version, git_commit
